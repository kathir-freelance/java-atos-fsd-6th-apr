package com.atos;

import java.util.HashSet;
import java.util.Set;

public class SetEx {

	public static void main(String[] args) {

		Set s=null;
		// hashset, treeset,linkedhashset
		s=new HashSet();
	/*	s.add(null);
		s.add(null);
		s.add("world");
		s.add(123);
		s.add(34.5f);
		System.out.println(s);
		s.add(new Emp());
		s.add(new Emp());
		s.add(new Adm());
		System.out.println(s);
		System.out.println(s.size());
		//s.get - no indexing supoported in set
		*/
		Emp e1=new Emp();
		
		s.add(e1); 
		s.add(e1);
		System.out.println(s.size());
		
	}

}

class Emp{
	
	//overriding hashcode and eq it ll be prob in identifying dupli of obj dded in set
}

class Adm{}