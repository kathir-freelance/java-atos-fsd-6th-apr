package com.atos;

import java.util.Set;
import java.util.TreeSet;

public class LinkedHashSetEx {

	public static void main(String[] args) {

			Set s=new TreeSet();//default - asc order , no dupl
		/*	s.add(111);
			s.add(1);
			s.add(1);
			s.add(14);
			s.add(12);
			s.add("hi");// clas cast excep
*/			
			/*s.add("alpha");
			s.add("Alpha");
			s.add("ALPHA");
			s.add("beta");
			s.add("111");*/
//			System.out.println(s);
			s.add(new Emp1());// implement comparable in the emp1 class and override compare
			System.out.println(s);		
	}

}
class Emp1{}