package com.atos;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue q=null;
		//q=new LinkedList();
		q=new PriorityQueue<>();
	//	q.add("hi");
		q.add(900);
		q.add(900);
	//	q.add(null);
		q.add(909);
	//	q.add('c');
		System.out.println(q);
		
	}

}
