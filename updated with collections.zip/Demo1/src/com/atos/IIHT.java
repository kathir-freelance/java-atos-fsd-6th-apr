package com.atos;

public class IIHT implements IContractSpring {

	int balance=0;
	

	public void celeb()
	{
		System.out.println("celebration");
	}

	@Override
	public void trainingJava() {
		balance=IContract.NO_OF_DAYS-15;
		System.out.println("java training is done - jsp has to start- bal days : "+balance);
	}

	@Override
	public void trainingJspServ() {
		balance=balance-15;
		System.out.println("jsop training is done Bal days: "+balance);
		System.out.println(balance+" is for assesment");
	}



	@Override
	public void trainingSpring() {
		System.out.println("in iiht spring");
	}


	@Override
	public void trainingSpringBoot() {
		System.out.println("in iiht spring boot");
	}
}
