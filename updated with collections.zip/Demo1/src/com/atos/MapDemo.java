package com.atos;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map m=null;
		m=new HashMap<>();
		m.put('I',"one");
		m.put(2, "second");
		m.put(3.0f,3);
		System.out.println(m);
		Collection c=m.values();
		System.out.println(c);
		Set s=m.keySet();
		System.out.println(s);
		
		Set s1=m.entrySet();
		System.out.println(s1);
		
		
	}

}
