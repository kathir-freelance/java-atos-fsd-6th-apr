package com.atos;

import java.util.HashMap;
import java.util.Map;

public class MapEx2 {

	public static void main(String[] args) {
		
		Map m=null;
		m=new HashMap();
		m.put("1","one");
		m.put("two",2);
		m.put("II",2);
		m.put('3', "3");
		m.put('3', "3");
		m.put(3.0f,new Integer(3));
		m.put(3.0f, "new value");
		m.put(null, null);
		m.put(null, "its null");
		System.out.println(m);
		
		
		
	}

}
