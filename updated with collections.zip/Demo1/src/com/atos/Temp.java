package com.atos;

public class Temp<T> {

	public T a;
	public T display(T b){
		return b;
	}
}
