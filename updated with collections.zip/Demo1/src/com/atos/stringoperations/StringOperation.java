package com.atos.stringoperations;

import java.util.Scanner;

public class StringOperation {

	public static void main(String[] args) {

		 String s="hello";//@32242
		 System.out.println(s);
		 s.concat("world");//it stores the value in a new mem location
		 System.out.println("after concatenation "+s);
		 s=s+" pls work";//(mem of s+plswork is @343)
		 System.out.println("after joining using '+' : "+s);
		 //after reassigning
		 s=s.concat("world");//(mem - @456)
		 System.out.println("after re-assigning"+s);
		 
		 String s1="HELLO";
		 System.out.println("lower case "+s1.toLowerCase());
		 String s2="world";
		 System.out.println("uppr case "+s2.toUpperCase());	
		 
		 System.out.println("char at position 3 :"+s2.charAt(3));
		 System.out.println(s2.endsWith("d"));
		 System.out.println(s2.equalsIgnoreCase("wORLD"));
		 System.out.println(s2.hashCode());
		 System.out.println("index of w "+s2.indexOf('w'));// implicit conv
		 s2=null;
		if(s2!=null)
			System.out.println(s2.isEmpty());
		 s2="";
		 System.out.println(s2.isEmpty());
		 
		 //s2=s2.replace("", "a");
		 s2="in the weird world everything is weird";
		 System.out.println(s2.replace('w','W'));
		 System.out.println(s2.replaceAll("d","D"));
		 System.out.println("contnt in s2 is "+s2+"  length "+s2.length());
		 
		 Scanner scan=new Scanner(System.in);
		/* System.out.println("pls enter the info");
		 String	 name=scan.nextLine();
		 
		 System.out.println("pls enter ur id");
		 int id=scan.nextInt();
		 
		 System.out.println("id is "+id);
		 System.out.println("name is "+name);
		*/ 
		 System.out.println("pls enter all days seperated by space");
		 String days=scan.nextLine();//mon-tue-wed thu fr
		 
		 String d[]=days.split("in");
		 for(String in:d)
		 {
			 System.out.println(in);
		 }
		 
		 String grades="ABCDE";
		 char ss[]=grades.toCharArray();
		 for(char f:ss)
		 {
			 System.out.println(f);
		 }
		 
		 char alp[]={'f','i','s','h'};
		 String s6=new String(alp);
		 System.out.println(s6);
		 
		 String pass="pass123";//charset encoder
		 for(byte b:pass.getBytes()){
			 System.out.println(b);
		 }
		 
		 String s7="Hello";
		 String s8=new String("Hello");
		 //s8 contains the ref of interned string 
		 
		 System.out.println(s7==s8);//mem or ref chk 
		 System.out.println(s7.equals(s8));// c0ontent check
		 System.out.println(s7.hashCode());
		 System.out.println(s8.hashCode());
	}
	

}
