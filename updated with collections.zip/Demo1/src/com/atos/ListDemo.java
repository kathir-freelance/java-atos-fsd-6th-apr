package com.atos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {
	
		List l=new ArrayList();
		l.add("hi");
		l.add("100");
		l.add("100");
		l.add(900);
		l.add(900);// implicit conversion happens - boxing
		l.add("welcome");
		l.add('c');
		l.add(78.6f);
		l.add(78.6f);
		System.out.println(l);
		//arraylist - growable array
		System.out.println(l.get(5));
		l.add(5, 6000);
		System.out.println(l);
		
		//set method is used for replacing content at specified point
		System.out.println(l.isEmpty());
	//	l.clear();
	//	System.out.println(l);
	//	System.out.println(l.isEmpty());
		Iterator i=l.iterator();
		while(i.hasNext()){
		//	l.add(90000);
			if(i.next().equals("hi"))
			i.remove();
			System.out.println(i.next());
		}

		System.out.println(l);
		
		System.out.println(l.isEmpty());
		//if(l.size()!=0) //not recom
	}

}
