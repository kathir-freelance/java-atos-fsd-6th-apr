class Primate
{
	public void walk()
	{
		System.out.println("uses 2 legs and 2 hands");
	}
}

class Human extends Primate
{
	//copy of all base methods will be here
	public void walk()
	{
	 super.walk();//super is base obj and super()- base class constructor call
	 System.out.println("human got evovled - enhanced");
	 super.walk();
	 System.out.println("uses only 2 legs");
	}

}

class TestInher2
{
	public static void main(String...ar)
	{
 		Human h=new Human();
		h.walk();
		int a=(int)10.5f;
		int b='a'; //implicit conversion
	 System.out.println("answer is "+b);
		
	}
}