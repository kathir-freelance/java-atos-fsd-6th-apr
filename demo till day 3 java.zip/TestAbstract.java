class TestAbstract
{
	public static void main(String ar[])
	{
		//AbstractDemo ob=new AbstractDemo();
		System.out.println(1 % 0.0);
		AbstractDemo ob=new Sub();
		ob.getName();
		ob.getData();
		ob.getMobile();
			
		ob=new NewSub();
		ob.getName();
		ob.getData();
		ob.getMobile();
		ob=new Sub();
		if(ob instanceof Sub)
		{
		Sub bs=(Sub)ob;
		bs.display();
		}
	}
}

abstract class AbstractDemo
{
	AbstractDemo(){

	}
	public abstract void getData();	
	public abstract void getName();	
	public void getMobile()	
	{
		System.out.println("get mobile number");
	}	
}


class Sub extends AbstractDemo
{
	
		public void getName()
		{
		System.out.println("get name using scanner");
		}	
		public void getData(){
			
		}
		public void display()
		{
		System.out.println("displaying the output");
		}	
}
class B extends Sub{
	
}
class NewSub extends AbstractDemo
{
	
		public void getName()
		{
		System.out.println("get info iusing file reader");
		}	
		public void getData(){
		System.out.println("get data using console io");
		}
		
}
