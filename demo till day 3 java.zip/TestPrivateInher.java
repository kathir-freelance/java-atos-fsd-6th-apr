class A
{

	public void m1()
	{
	System.out.println("in m1");
	}
	private void m2(){
	System.out.println("in m2");
	}
	public static void m4()
	{
	System.out.println("class A - m4");
	}
	

}
class B extends A
{
/*	@Override
	public void m2(){
	System.out.println("class B in m2");
	}

	@Override
	public void m3()
	{
	}
*/
	public static void m4()
	{
	//super.m4();
	System.out.println("class B in m4");
	}

}

class TestPrivateInher
{
	public static void main(String ar[])
	{
		System.out.println(1 % 0.0);
		B ob=new B();
	//	ob.m1();
	//	ob.m2();	
		ob.m4();
	
	}
}
