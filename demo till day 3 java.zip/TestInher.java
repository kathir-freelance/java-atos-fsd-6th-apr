public class TestInher
{	
	public static void main(String...a)
	{
	 System.out.println("in main");	
		Scientific ob=new Scientific();
		ob.add();	
		ob.sub();
		ob.sin(90.0f);
		//ob.displayop();//not poss

		Calculator cal=new Calculator ();
		cal.add();
		cal.sub();
		//cal.sin();//compilation err
		//cal.displayop();//not poss
	}
}

//java.lang.Object
class Calculator 
{
	private void displayop()
	{
		System.out.println("o/p in calc class");
	}
	
	public void add()
	{
	System.out.println("add..");
	displayop();
	}

	public void sub()
	{
	System.out.println("sub..");
	}

}

class Scientific extends Calculator
{
	public void sin(float angle)
	{
		System.out.println("o/p of sin is : "+1);
	}
}

class Programming extends Calculator
{
	
}
	

