class Trainer extends Human
{
	public void talk()
	{
	System.out.println("talk of human - training related");
	}		
}

class Human
{
	public void talk()
	{
	System.out.println("talk of human - general");
	}	
}

class TestPoly
{
	public static void main(String ar[])
	{
		Human h=null;//ref variable
		h=new Human();
		h.talk();	
		h=new Trainer();
		h.talk();
	}

}


lady - base

	empl
	Home maker
	member