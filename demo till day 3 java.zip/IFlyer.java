interface IFlyer{
	float PI=3.14f;

	void fly();
	public default void land()
	{
	//	a=9000;//cant assign value
		System.out.println("landing");
	}
	public static void takeOff()
	{
		System.out.println("take off");
	}
}

