package com.atos;

public class Company {

	public static void main(String ar[]){
		
		IContract ic=null;
		ic=new IIHT();
		ic.trainingJava();
		ic.trainingJspServ();
		if(ic instanceof IIHT)
		{
			IIHT i=(IIHT)ic;
			i.celeb();
		}
		
		ic=new NIIT();
		ic.trainingJava();
		ic.trainingJspServ();
		
	}
}
