package com.atos;

public class IIHT implements IContract {

	int balance=0;
	
	@Override
	public void trainingJava() {
		balance=IContract.NO_OF_DAYS-15;
		System.out.println("java training is done - jsp has to start- bal days : "+balance);
	}

	@Override
	public void trainingJspServ() {
		balance=balance-15;
		System.out.println("jsop training is done Bal days: "+balance);
		System.out.println(balance+" is for assesment");
	}

	public void celeb()
	{
		System.out.println("celebration");
	}
}
