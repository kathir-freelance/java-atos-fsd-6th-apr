package com.atos.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//controller

@WebServlet(urlPatterns={"*.do"})// servlet 3.0 onwards<servlet> <servlet mapping>
public class MyServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("hi");
		//logic
		String path=req.getServletPath();
		System.out.println(path);
		
		switch(path){
		
		case "/add.do":
		String n=req.getParameter("name");
		float p=Float.parseFloat(req.getParameter("price"));
		int qty=Integer.parseInt(req.getParameter("qty"));
		Product prod=new Product(n,p,qty);
			addProduct(prod);
			break;
		case "/delete.do":
			deleteProduct();
			break;
		
		case "/update.do":
			updateProduct();
			break;
			default:
				break;
		}
	}
	
	private ProductService serv;
	public MyServlet() {
		System.out.println("in constr");
	}

	@Override
	public void init() throws ServletException {
		System.out.println("in init");
		serv=new ProductService();
	}
	void addProduct(Product p){
		System.out.println(" in add - ctlr");
		serv.addProduct(p);
	}
	void deleteProduct(){
		System.out.println("in delete");
	}
	void updateProduct(){
		System.out.println("in update");
	}
	

}