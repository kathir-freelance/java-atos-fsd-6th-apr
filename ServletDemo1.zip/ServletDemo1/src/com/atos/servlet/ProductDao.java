package com.atos.servlet;

import java.util.HashMap;
import java.util.Map;

public class ProductDao {

	Map<String, Product> prodList=null;
	public ProductDao() {
		prodList=new HashMap<>();
		
	}
	void addProduct(Product p){
		
		prodList.put(p.getProdName(),p);
		System.out.println(prodList);
	}
	void deleteProduct(){
	}
	void updateProduct(){
	}
}
