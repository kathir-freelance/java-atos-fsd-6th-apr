package com.atos.servlet;

import java.util.HashMap;

public class ProductService {
//validation
	ProductDao dao=null;
	
	public ProductService() {
		dao=new  ProductDao();
		
	}
	void addProduct(Product p){
		
		System.out.println("in serv ");
		dao.addProduct(p);
		
	}
	void deleteProduct(){
	}
	void updateProduct(){
	}
	
}
