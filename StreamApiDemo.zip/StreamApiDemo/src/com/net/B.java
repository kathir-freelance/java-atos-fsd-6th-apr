package com.net;

public class B {

	public static void main(String[] args) {
		A ob=new A();
		ob.get();
	}

}
