package com.net;

public class A {

	void get(){
	System.out.println("get neth of A");
	}
}
