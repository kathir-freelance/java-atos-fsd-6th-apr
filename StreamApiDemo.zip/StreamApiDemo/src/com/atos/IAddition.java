package com.atos;

//@FunctionalInterface
public interface IAddition {

	public abstract void add(int a,int b);
	//public abstract void add1(int a,int b);
}
