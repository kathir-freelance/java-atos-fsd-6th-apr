package com.atos;



public class AnnoatationEx {

	public static void main(String st){
		System.out.println("in main");
		
	}
}
class A{
	
}
class B extends A{
	//@Override
	public void getName(){
		
	}
}