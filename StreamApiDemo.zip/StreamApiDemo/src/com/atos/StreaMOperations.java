package com.atos;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
//public abstract interface java.util.stream.Stream extends java.util.stream.BaseStream*
public class StreaMOperations {
	

	public static void main(String[] args) {
		 Employee[] arrayOfEmps = {
			    new Employee(1, "Jeff Bezos", 100000.0f), 
			    new Employee(2, "Bill Gates", 200000.0f), 
			    new Employee(3, "Mark Zuckerberg", 300000.0f)
			};
		
		Stream s=Stream.of(arrayOfEmps);
		System.out.println(s);
		//s.forEach(System.out::println);
		Stream s3=s.limit(1);
		System.out.println(s3.count());
		System.out.println(s3.count());
		/*
		int a[]={1,2,43,4,5,5,56};
		//Stream s1=Stream.of(a);
		
		//s1.forEach(System.out::println);
		List l=Arrays.asList(a);
		System.out.println(l);
		Stream s1=l.stream();
		s1.forEach(System.out::println);
		*/
	}

}
