package com.atos;

import java.util.function.Supplier;

public class TestSupplier {

	public static void main(String[] args) {

			Supplier<Integer> supply=null;
			supply=()-> ((int)(Math.random()*1000/10)*123);
			int id=supply.get();
			System.out.println(id);
	}

}
