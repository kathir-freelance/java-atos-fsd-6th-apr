package com.atos;

public interface IGenareteId {

	//public int sub(int a,int  b);// not possible to apply supplie coz it takes input
	public abstract int generate();
}
