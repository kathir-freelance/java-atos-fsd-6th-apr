package com.atos;

public interface StringGenerator {

	//public abstract  String generateStrings();
	public abstract String modify(String s1);
}
