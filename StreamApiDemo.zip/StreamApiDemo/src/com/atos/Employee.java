package com.atos;

public class Employee {

	private int empId;
	private String name;
	private float sal;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the empId
	 */
	public int getEmpId() {
		return empId;
	}

	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the sal
	 */
	public float getSal() {
		return sal;
	}

	/**
	 * @param sal the sal to set
	 */
	public void setSal(float sal) {
		this.sal = sal;
	}

	public Employee(int empId, String name, float sal) {
		super();
		this.empId = empId;
		this.name = name;
		this.sal = sal;
	}
	
}
