package com.atos;

import java.util.function.Predicate;

//public abstract void add(int a,int b);

public class TestFunctInterface {

	public static void main(String[] args) {
	
		//IAddition add=new Adder();
		//add.add(10, 20);
		
		IAddition addr=null;
		addr=(int a,int b)->{
								int c=a+b;
								System.out.println("result is "+c);	
							};
		addr.add(100,200);					
	
		//public abstract  String generateStrings();
		StringGenerator sg=null;
	/*	sg=()-> "hello";
		
		System.out.println(sg.generateStrings());
		
		sg=()->{ String initial="Mr.";
				return initial+" name";
				};
		System.out.println(sg.generateStrings());		
		
		sg=()->{return "Mr. "+"ajay";};
		System.out.println(sg.generateStrings());
		sg=()-> "Mr. "+"ajay";
		System.out.println(sg.generateStrings());
*/	
		//public abstract String modify(String s1);
		sg=(str)->(str.substring(2,5)).toUpperCase();//implicitly the datatype of str is string
															//checks and matches with target					
		System.out.println(sg.modify("helloworld"));
		
		//supplier - bisupplier
		//no input need , but gives value
		
		
		//consumer - biConsumer
		// input is need, but no o/p returned
		
		//predicate-BiPredicate
		//takes input but returns T or False 
		
		//function-BiFunction
		//takes input 1 or 2, returns o/p
		
		//public abstract boolean check(int num);
		
		/*EvenChecker e=null;
		e=(num)-> (num%2==0)?true:false;
		boolean stat=e.check(88);
		if(stat)
		System.out.println("yes!! its even");
		else
		System.out.println("not an even");*/
		
		Predicate e=null;
		e=(num)-> ((Integer)num%2==0)?true:false;
		boolean stat=e.test(88);
		if(stat)
		System.out.println("yes!! its even");
		else
		System.out.println("not an even");
	}

}




/*class Adder implements IAddition{

	@Override
	public void add(int a, int b) {
		int c=a+b;
		System.out.println("result is "+c);
	}
	
}*/