package com.atos;

//by default its qualified as FUNC interface

@FunctionalInterface
public interface IFlyer {
	public abstract void fly();

	int P=90;
	
	public default void defMeth(){
		
	}
	public default void defMeth(int a){
		
	}
	public default void defMeth(float a){
		
	}
	public static void statMeth(){
		
	}
}
