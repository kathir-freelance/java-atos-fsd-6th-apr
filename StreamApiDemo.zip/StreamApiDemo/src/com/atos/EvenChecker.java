package com.atos;

public interface EvenChecker {

	public abstract boolean check(int num);
}
