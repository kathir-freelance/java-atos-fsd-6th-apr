package com.atos;

public class FunctionalIngterEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

